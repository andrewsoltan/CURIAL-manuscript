Name of the folder shows the considered feature set (e.g., Blood & BloodGas shows a combination of blood and blood gas markers for feature) or the value that was used to set the threshold (e.g., 0.8)

10CV_Mean_Multiple_Imputation and 10CV_Std_Multiple_Imputation are the mean and std of 10 fold cross validation on the train set.

Test_Mean_Multiple_Imputation and Test_Std_Multiple_Imputation are performance evaluation on the test set

Test_Mean_Importance and Test_Std_Importance are the mean and standard importance of features

Prevalence = 1/(Match Number +1)
